<?php

//use archive template
require_once('archive-gb_charities.php');
