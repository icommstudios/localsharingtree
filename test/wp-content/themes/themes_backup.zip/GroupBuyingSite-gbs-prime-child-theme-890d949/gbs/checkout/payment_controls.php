<div class="alert danger text-center"><h4>Note: All fields are required to Checkout.</h4></div>

<div class="checkout-controls text-center clearfix">
	<?php foreach ( $form_controls as $control ): ?>
		<?php echo $control; ?>
	<?php endforeach; ?>
	<p>All transactions are processed through <strong>Paypal's Secure Server</strong>. However, a Paypal account is NOT REQUIRED.<br>You will have the option to pay with a credit card OR a PayPal account.</p>
</div>
