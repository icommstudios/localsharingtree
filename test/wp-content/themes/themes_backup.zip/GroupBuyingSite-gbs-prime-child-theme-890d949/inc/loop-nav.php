<span class="clearfix">&nbsp;</span>
<?php wp_pagination(); ?>