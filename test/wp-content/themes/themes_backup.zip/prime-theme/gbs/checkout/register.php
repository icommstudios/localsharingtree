<?php 
	foreach ( $panes as $pane ) {
		echo $pane['body'];
	} 
?>
<?php do_action('gb_account_register_form'); ?>