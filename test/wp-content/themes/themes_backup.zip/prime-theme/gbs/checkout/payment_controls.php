<div class="checkout-controls clearfix">
	<?php foreach ( $form_controls as $control ): ?>
		<?php echo $control; ?>
	<?php endforeach; ?>
</div>
