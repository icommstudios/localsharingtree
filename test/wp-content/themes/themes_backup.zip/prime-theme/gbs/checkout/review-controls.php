<div class="checkout-controls clearfix">
	<input class="form-submit submit checkout_next_step" type="submit" value="<?php gb_e('Submit Order'); ?>" name="gb_checkout_button" />
</div>
