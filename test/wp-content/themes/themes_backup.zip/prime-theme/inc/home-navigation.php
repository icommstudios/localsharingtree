<div id="starter_wrap" class="clearfix">
	<div id="starter" class="container clearfix">
		
		<div class="home_login_wrap contrast font_small"><?php gb_facebook_button(); ?><?php gb_e('Already have an account?') ?> <a href="<?php gb_account_url() ?>"><?php gb_e('Login') ?></a></div>
		
	</div><!-- #starter -->
</div><!--  .-->