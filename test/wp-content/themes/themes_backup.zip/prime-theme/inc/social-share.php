<div class="social_buttons clearfix">
	<span class='st_facebook_large' displayText='Facebook' st_url="<?php gb_share_link() ?>"></span>
	<span class='st_twitter_large' displayText='Tweet' st_url="<?php gb_share_link() ?>"></span>
	<span class='st_pinterest_large' displayText='Pinterest' st_url="<?php gb_share_link() ?>"></span>
	<span class='st_sharethis_large' displayText='ShareThis' st_url="<?php gb_share_link() ?>"></span>
	<span class='st_email_large' displayText='Email' st_url="<?php gb_share_link() ?>"></span>
</div><!-- #label -->