<span class="clearfix">&nbsp;</span>
<div id="nav_below" class="clearfix">
	<div class="nav_previous"><?php next_posts_link( gb__( '<span class="meta-nav">&larr;</span> Older deals' ) ); ?></div>
	<div class="nav_next"><?php previous_posts_link( gb__( 'Newer deals <span class="meta-nav">&rarr;</span>' ) ); ?></div>
</div><!-- #nav+below -->